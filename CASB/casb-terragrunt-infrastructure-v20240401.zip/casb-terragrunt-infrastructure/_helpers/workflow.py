import argparse
import logging
import os
import pathlib
import re
import subprocess
import sys
import tempfile
from enum import Enum
from typing import List
from zipfile import ZipFile

import jsonpickle
import requests
import yaml
from tabulate import tabulate
from yaml.loader import SafeLoader

logger = logging.getLogger(__file__)

working_dir = pathlib.Path(__file__).parent.parent.absolute()
modules_dir = os.path.join(working_dir, "_modules")
output_dir = os.path.join(working_dir, "_output")
plan_dir = os.path.join(working_dir, "_plan")
plugin_cache_dir = os.path.join(working_dir, ".terraform.d", "plugin-cache")

sites = []
modules = []


class PlanStatus(str, Enum):
    UNKNOWN = "Unknown"
    NO_CONFIG = "-"
    NO_CHANGE = "√"
    SUCCESS = "Success"
    FAILURE = "Failure"


class Plan:
    def __init__(self):
        self.site = ""
        self.module = ""
        self.status = PlanStatus.UNKNOWN
        self.cnt_add = 0
        self.cnt_change = 0
        self.cnt_destroy = 0

    def __eq__(self, other: object) -> bool:
        return hasattr(other, "__dict__") and self.__dict__ == other.__dict__


def create_table(sites: List[str], modules: List[str], plans: List[Plan]) -> str:
    data = []
    row = ["Site"]
    row.extend(sites)
    data.append(row)
    for module in modules:
        row = [module]
        data.append(row)
        for site in sites:
            res = list(filter(lambda x: x.site == site and x.module == module, plans))
            if len(res) == 0 or res[0].status == PlanStatus.NO_CONFIG:
                row.append(PlanStatus.NO_CONFIG.value)
                continue
            plan = res[0]
            if plan.status != PlanStatus.SUCCESS:
                row.append(plan.status.value)
                continue
            row.append(
                "+%d !%d -%d" % (plan.cnt_add, plan.cnt_change, plan.cnt_destroy)
            )
    return tabulate(data, headers="firstrow", tablefmt="fancy_grid")


def init_logger(level=logging.INFO):
    formatter = logging.Formatter("%(asctime)s %(levelname)5s - %(message)s")
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    handler.setLevel(level)
    logger.addHandler(handler)
    logger.setLevel(level)


def scan_dir(path) -> List[str]:
    return sorted(
        map(
            lambda d: d.name,
            filter(
                lambda x: x.is_dir()
                and not x.name.startswith(".")
                and not x.name.startswith("_"),
                os.scandir(path),
            ),
        )
    )


def cmd_apply(args):
    download_plugins()

    envs = dict(os.environ)
    envs["TF_PLUGIN_CACHE_DIR"] = plugin_cache_dir
    envs["TF_PLUGIN_CACHE_MAY_BREAK_DEPENDENCY_LOCK_FILE"] = "true"

    for site in sites:
        logger.info("site=%s", site)
        site_dir = os.path.join(working_dir, site)
        for module in modules:
            print("::group::site=%s, module=%s" % (site, module), file=sys.stderr)
            module_dir = os.path.join(site_dir, module)
            if not os.path.exists(module_dir):
                logger.warning(
                    "site=%s, module=%s, directory %s not exist",
                    site,
                    module,
                    module_dir,
                )
                print("::endgroup::", file=sys.stderr)
                continue

            cmd = ["terragrunt", "apply", "-auto-approve"]
            child = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=dict(envs, TERRAGRUNT_WORKING_DIR=module_dir),
            )
            stdout, stderr = child.communicate()
            logger.info("\n".join(["stdout:", stdout.decode().strip()]))
            logger.info("\n".join(["stderr:", stderr.decode().strip()]))
            print("::endgroup::", file=sys.stderr)
            if child.returncode:
                logger.error(f"Exit code: {child.returncode}")
                exit(child.returncode)


def cmd_plan(args):
    download_plugins()

    envs = dict(os.environ)
    envs["TF_PLUGIN_CACHE_DIR"] = plugin_cache_dir
    envs["TF_PLUGIN_CACHE_MAY_BREAK_DEPENDENCY_LOCK_FILE"] = "true"

    plans = []
    for site in sites:
        logger.info("site=%s", site)
        site_dir = os.path.join(working_dir, site)
        site_plans: List[Plan] = []
        for module in modules:
            print("::group::site=%s, module=%s" % (site, module), file=sys.stderr)
            plan = Plan()
            plan.site = site
            plan.module = module
            site_plans.append(plan)

            module_dir = os.path.join(site_dir, module)
            if not os.path.exists(module_dir):
                plan.status = PlanStatus.NO_CONFIG
                logger.warning(
                    "site=%s, module=%s, directory %s not exist",
                    site,
                    module,
                    module_dir,
                )
                print("::endgroup::", file=sys.stderr)
                continue

            cmd = ["terragrunt", "plan"]
            child = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=dict(envs, TERRAGRUNT_WORKING_DIR=module_dir),
            )
            stdout, stderr = child.communicate()
            output = "\n".join([stdout.decode().strip(), stderr.decode().strip()])

            if output.find("no changes are needed") != -1:
                plan.status = PlanStatus.NO_CHANGE
                logger.info("site=%s, module=%s, no changes are needed", site, module)
                logger.debug("\n".join(["stdout:", stdout.decode().strip()]))
                logger.debug("\n".join(["stderr:", stderr.decode().strip()]))
                print("::endgroup::", file=sys.stderr)
                continue

            m = re.search(
                r"(?P<add>\d+) to add, (?P<change>\d+) to change, (?P<destroy>\d+) to destroy",
                output,
            )
            if m:
                plan.status = PlanStatus.SUCCESS
                plan.cnt_add = int(m.group("add"))
                plan.cnt_change = int(m.group("change"))
                plan.cnt_destroy = int(m.group("destroy"))
            if output.find("Changes to Outputs:") != -1:
                # The changes to outputs are counted as one change.
                plan.status = PlanStatus.SUCCESS
                plan.cnt_change += 1

            if plan.status != PlanStatus.SUCCESS:
                plan.status = PlanStatus.FAILURE
                logger.warning("site=%s, module=%s, unable to plan", site, module)
                logger.warning("\n".join(["stdout:", stdout.decode().strip()]))
                logger.warning("\n".join(["stderr:", stderr.decode().strip()]))
                print("::endgroup::", file=sys.stderr)
                continue
            logger.info(
                "site=%s, module=%s, plan add %d, change %d, destroy %d",
                site,
                module,
                plan.cnt_add,
                plan.cnt_change,
                plan.cnt_destroy,
            )
            logger.info("\n".join(["stdout:", stdout.decode().strip()]))
            logger.info("\n".join(["stderr:", stderr.decode().strip()]))
            print("::endgroup::", file=sys.stderr)
        plans.extend(site_plans)

        site_output_dir = os.path.join(output_dir, site)
        os.makedirs(site_output_dir, exist_ok=True)

        site_file_path = os.path.join(site_output_dir, "plan.json")
        with open(site_file_path, "w", encoding="utf-8") as handle:
            handle.write(jsonpickle.encode(site_plans))

    table = create_table(sites, modules, plans)
    logger.info("\n%s", table)

    file_path = os.path.join(working_dir, "plan.txt")
    with open(file_path, "w", encoding="utf-8") as handle:
        handle.write(table)
        logger.info("Write plan summary to %s", file_path)


def cmd_summarize(args):
    plans: List[Plan] = []
    for site in sites:
        file_path = os.path.join(plan_dir, site, "plan.json")
        if not os.path.exists(file_path):
            logger.warning("The file %s does not exist", file_path)
            continue
        with open(file_path, "r", encoding="utf-8") as handle:
            site_plans: List[Plan] = jsonpickle.decode(handle.read())
            plans.extend(site_plans)
    modules = list(set([x.module for x in plans]))
    modules.sort()

    table = create_table(sites, modules, plans)
    logger.info("\n%s", table)

    file_path = os.path.join(working_dir, "plan.txt")
    with open(file_path, "w", encoding="utf-8") as handle:
        handle.write(table)
        logger.info("Write plan summary to %s", file_path)


def download_plugins():
    conf_path = os.path.join(working_dir, "plugins.yaml")
    if not os.path.exists(conf_path):
        logger.warning(f"Skip downloading plugins, missing {conf_path}")
        return
    with open(conf_path, "r", encoding="utf-8") as handle:
        conf = yaml.load(handle, Loader=SafeLoader)

    for module in conf:
        v = conf[module]
        bin_path = os.path.join(plugin_cache_dir, v["localBin"])
        if os.path.exists(bin_path):
            logger.info(f"Skip downloading {module}, already exist")
            continue

        r = requests.get(v["downloadUrl"])
        with tempfile.NamedTemporaryFile(suffix=".zip") as t:
            t.write(r.content)
            t.seek(0)
            z = ZipFile(t)
            z.extractall(os.path.dirname(bin_path))
            logger.info(f'Download {module} from {v["downloadUrl"]}')

    os.chmod(plugin_cache_dir, 0o755)
    for dirpath, dirnames, filenames in os.walk(plugin_cache_dir):
        for dname in dirnames:
            os.chmod(os.path.join(dirpath, dname), 0o755)
        for fname in filenames:
            os.chmod(os.path.join(dirpath, fname), 0o755)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--log-level",
        type=str,
        choices=["INFO", "DEBUG"],
        default="INFO",
        dest="log_level",
        help="log level (default: INFO)",
    )
    parser.add_argument(
        "--sites",
        type=str,
        dest="sites",
        help="comma separated sites. Default all sites.",
    )
    parser.add_argument(
        "--modules",
        type=str,
        dest="modules",
        help="comma separated modules. Default all modules.",
    )

    subparsers = parser.add_subparsers()
    parser_plan = subparsers.add_parser("plan", help="run terragrunt plan respectively")
    parser_plan.set_defaults(func=cmd_plan)

    parser_summarize = subparsers.add_parser(
        "summarize", help="summarize the plan results"
    )
    parser_summarize.set_defaults(func=cmd_summarize)

    parser_apply = subparsers.add_parser(
        "apply", help="run terragrunt apply respectively"
    )
    parser_apply.set_defaults(func=cmd_apply)
    args = parser.parse_args()

    # Initialize the global logger
    init_logger(args.log_level)

    logger.info("With working dir: %s", working_dir)
    if not os.path.exists(plugin_cache_dir):
        os.makedirs(plugin_cache_dir)
    logger.info("With plugin cache dir: %s", plugin_cache_dir)

    global sites
    if args.sites and args.sites != "ALL":
        sites = [x.strip() for x in args.sites.split(",")]
    else:
        sites = scan_dir(working_dir)
    logger.info("With sites: %s", ", ".join(sites))

    global modules
    if args.modules and args.modules != "ALL":
        modules = [x.strip() for x in args.modules.split(",")]
    else:
        modules = []
        for site in sites:
            site_dir = os.path.join(working_dir, site)
            site_modules = scan_dir(site_dir)
            modules = list(set(modules).union(set(site_modules)))
        modules.sort()
    logger.info("With modules: %s", ", ".join(modules))

    if "func" in args:
        args.func(args)


if __name__ == "__main__":
    main()
