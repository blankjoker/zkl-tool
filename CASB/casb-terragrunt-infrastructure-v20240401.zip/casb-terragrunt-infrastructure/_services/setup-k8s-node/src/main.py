import argparse
import logging
import os
import sys

logger = logging.getLogger(__file__)


def init_logger(level=logging.INFO):
    formatter = logging.Formatter("%(asctime)s %(levelname)5s - %(message)s")
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    handler.setLevel(level)
    logger.addHandler(handler)
    logger.setLevel(level)


def update_etc_hosts(file_path: str, data: dict[str, set[str]]):
    """Add additional mapping to /etc/hosts.

    :param file_path: mounted path of host /etc/hosts.
    :param data: key is the ip address, value is the hostnames.
    """
    with open(file_path, "r") as handle:
        src = handle.read()
        logger.info("Read %s:\n%s", file_path, src)

    src_lines = src.splitlines()
    dst_lines = src_lines.copy()
    for line in src_lines:
        parts = line.split()
        if not len(parts):
            continue
        ip = parts[0]
        if not data.get(ip):
            continue
        data[ip] = data[ip].difference(set(parts[1:]))
    for ip in data:
        if len(data[ip]) > 0:
            dst_lines.append("%s\t%s" % (ip, " ".join(data[ip])))

    dst = os.linesep.join(dst_lines)
    if src == dst:
        logger.info("No need to update %s", file_path)
        return

    with open(file_path, "w") as handle:
        handle.write(dst)
        logger.info("Write %s as:\n%s", file_path, dst)


def update_etc_containerd_skip_verify(dir_path: str, host: str):
    """Set skip_verify as true by updating /etc/containerd/.

    :param dir_path: mounted path of host /etc/containerd/.
    :param host: the container registry.
    """
    namespace = host.removeprefix("http://").removeprefix("https://")
    dst_dir = os.path.join(dir_path, "certs.d", namespace)
    os.makedirs(dst_dir, exist_ok=True)

    dst_path = os.path.join(dst_dir, "hosts.toml")
    dst = f'[host."{host}"]\n  skip_verify = true'
    if os.path.exists(dst_path):
        with open(dst_path, "r") as handle:
            src = handle.read()
            logger.info("Read %s:\n%s", dst_path, src)
        if src == dst:
            logger.info("No need to update %s", dst_path)
            return

    with open(dst_path, "w") as handle:
        handle.write(dst)
        logger.info("Write %s as:\n%s", dst_path, dst)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--etc-dir",
        type=str,
        default="/etc",
        dest="etc_dir",
        help="host /etc volume mount path",
    )
    args = parser.parse_args()

    init_logger()
    logger.info("Python %s", sys.version)

    etc_dir = args.etc_dir
    logger.info("With param --etc-dir %s", etc_dir)

    update_etc_hosts(
        os.path.join(etc_dir, "hosts"), {"43.254.158.101": {"harbor.sangfor.com"}}
    )
    update_etc_containerd_skip_verify(
        os.path.join(etc_dir, "containerd"), "https://harbor.sangfor.com:32191"
    )


if __name__ == "__main__":
    main()
