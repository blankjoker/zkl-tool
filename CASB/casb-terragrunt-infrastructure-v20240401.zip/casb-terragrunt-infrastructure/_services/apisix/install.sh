#!/bin/bash
CUR_DIR=$(dirname "$(realpath -s "$0")")

# CASB site name: dev-eastasia, prod-westeurope
site="${CASB_SITE:=dev-dummy}"

k8s_namespace="casb"
k8s_context_name="aks-casb-$site"

apisix_chart_version="2.6.0"

# Update helm repo if necessary.
#
#   helm repo add apisix https://charts.apiseven.com
#   helm repo add bitnami https://charts.bitnami.com/bitnami
#   helm repo update

helm upgrade apisix apisix/apisix \
  --kube-context "$k8s_context_name" \
  --install \
  --version "$apisix_chart_version" \
  --create-namespace \
  --namespace "$k8s_namespace" \
  --values "$CUR_DIR/values.yaml" \
  --values "$CUR_DIR/values-$site.yaml" \
  --set ingress-controller.config.apisix.serviceNamespace="$k8s_namespace"
kubectl get service --namespace "$k8s_namespace"
