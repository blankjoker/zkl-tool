export GOROOT=$HOME/go
export GOPATH=$HOME/gopath
export PATH=$GOROOT/bin:$GOPATH/bin:$PATH
export GOPROXY="http://mirrors.sangfor.org/nexus/repository/go-proxy"
