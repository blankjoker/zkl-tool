import json
import os
import fire

just_show = False

def debug(msg):
    if just_show:
        print("[DEBUG] %s" % msg)

def info(msg):
    print("[INFO] %s" % msg)

def error(msg):
    print(f"[ERROR] %s" % msg)
    exit(-1)

def warn(msg):
    print(f"[WARN] %s" % msg)


def getTemplateDetails(version, msName, tpl):
    cmd = f'kubectl get allocations.mayor.sfc.sangfor -A -lmsName={msName},version={version} -ojson'
    debug(f"cmd = '{cmd}'")
    tmp = os.popen(cmd)
    cfg = json.load(tmp)
    if len(cfg["items"]) != 1:
        warn(f"getTemplateDetails error, tpl='{tpl}', cmd='{cmd}', result={cfg}")
        return

    ret = {
        "allocation": cfg["items"][0]["metadata"]["name"],
        "namespace": cfg["items"][0]["metadata"]["namespace"]
    }

    if "meta.helm.sh/release-name" in cfg["items"][0]["metadata"]["annotations"]:
        ret["helm"] = cfg["items"][0]["metadata"]["annotations"]["meta.helm.sh/release-name"]

    return ret

def getTemplateAppeVersion(tpl, msName):
    tmp = os.popen(f"kubectl get templateversions.controller.sfc.sangfor -n default {tpl} -ojson")
    data = json.load(tmp)

    if msName == "fwaas":
        return getTemplateDetails(data["spec"]["fwaasKey"]["version"], "fwaas", tpl)

    for item in data["spec"]["services"]:
        if item["msName"] == msName:
            return getTemplateDetails(item["version"], item["msName"], tpl)

def getCurUsingTemplate(msName):
    tmp = os.popen("kubectl get eggs.controller.sfc.sangfor -o custom-columns=TENANTID:.metadata.labels.tenantId,EGG:.metadata.name,DESIRE:.spec.desire,TEMPLATE:.spec.desireMsTemplateVersion,STATUS:.status.eggPolymerResult.eggStatus,CREATEAT:.metadata.creationTimestamp | awk 'NR!=1{print $4}' | sort -u")
    data = tmp.read()
    tpls = data.split("\n")

    info(f"cur using template is {tpls}")
    ret = {}
    using_tpls = []
    for tpl in tpls:
        if tpl != "":
            using_tpls.append(tpl)
            if msName == "template-version":
                continue

            detail = getTemplateAppeVersion(tpl, msName)
            if detail != None:
                ret[detail["allocation"]] = detail

    debug(f"{msName} cur using version is {ret} {using_tpls}")
    return ret, using_tpls

def clearHelmResource(helms, msName):
    for item in helms.items():
        if len(item[1]) == 0:
            continue

        cmd = f"helm list -n {item[0]} | grep {msName}"
        allHelms = os.popen(cmd + "|awk '{print $1}'|sort -u").read()
        debug(f"allHelms: {allHelms}")
        
        for helm in item[1]:
            cmd += f"| grep -v {helm} "

        cmd += "|awk '{print $1}'|sort -u"
        debug(f"{cmd}")
        delHelms = os.popen(cmd).read()
        debug(f"delHelms: {delHelms}")
        
        if not delHelms:
            info(f"no need clear {msName} helm resource")
            return
        elif delHelms == allHelms:
            error("want clear all helms of %s, cmd='%s'" % (msName, cmd))
            return
            
        cmd += " | xargs helm uninstall -n %s" % item[0]
        info("clear helm cmd = '%s'" % cmd)
        if not just_show:
            tmp = os.popen(cmd)
            info(tmp.read())


def clearAlloctionResource(allocations, msName):
    for item in allocations.items():
        if len(item[1]) == 0:
            continue

        cmd = f"kubectl get allocations.mayor.sfc.sangfor -n {item[0]}"
        allAlloctions = os.popen(cmd + "|awk 'NR!=1{print $1}'|sort -u").read()
        debug(f"allAlloctions: {allAlloctions}")
        
        for allocation in item[1]:
            cmd += f"| grep -v {allocation} "

        cmd += "| awk 'NR!=1{print $1}'|sort -u"
        debug(f"{cmd}")
        delAlloctions = os.popen(cmd).read()
        debug(f"delAlloctions: {delAlloctions}")
        
        if not delAlloctions:
            info(f"no need clear {msName} allocation resource")
            return
        elif delAlloctions == allAlloctions:
            error("want clear all allocations of %s, cmd='%s'" % (msName, cmd))
            return
            
        cmd += "|xargs kubectl delete allocations.mayor.sfc.sangfor -n %s" % item[0]
        info("clear allocation cmd = '%s'" % cmd)
        if not just_show:
            tmp = os.popen(cmd)
            info(tmp.read())


def clearResource(msName, show=False):
    if show != False:
        global just_show
        just_show = bool(show)

    info(f"clear {msName} start, just show is {just_show}")
    apps, tpls = getCurUsingTemplate(msName)
        
    if msName == "template-version":
        clearHelmResource({"default":tpls}, msName)
        info(f"clear resource {msName} success")
        return
    elif not apps:
        info(f"{msName} is not found in template-version, skip")
        return

    helms = {}
    allocations = {}
    for item in apps.values():
        if item["namespace"] not in allocations:
            allocations[item["namespace"]] = []
            helms[item["namespace"]] = []


        if "allocation" in item:
            allocations[item["namespace"]].append(item["allocation"])
        if "helm" in item:
            helms[item["namespace"]].append(item["helm"])

    clearHelmResource(helms, msName)
    clearAlloctionResource(allocations, msName)
    info(f"clear resource {msName} success")

def help():
    print(
"""
Usage: python3 clear_resource.py <cmd>

    clear <msName> [show|optional]
        msName eg: fwaas, msgforward, sfflowstat, ac-sfappaudit-multi, ingress-server, nac-server, sfappctrl, safeserviced ,sdpgagent, template-version
        show: if show is true, will just show commands, not execute, default false.
"""
    )


if __name__ == "__main__":
    fire.Fire({
        "clear": clearResource,
        "help": help,
    })
